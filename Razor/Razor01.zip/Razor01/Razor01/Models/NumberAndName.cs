﻿namespace Razor01.Models
{
    public class NumberAndName
    {
        public int Number { get; set; }
        public string? Name { get; set; }

        public NumberAndName(int number, string? name)
        {
            Number = number;
            Name = name;
        }
    }
}
