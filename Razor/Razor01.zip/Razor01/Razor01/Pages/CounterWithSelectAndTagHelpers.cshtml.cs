using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Razor01.Pages
{
    public class CounterWithSelectAndTagHelpersModel : PageModel
    {
        public void OnGet()
        {
        }

        // SelectList to populate HTML select in Razor page
        public List<SelectListItem> slNumbers { get; }


        // string value to hold the selected value from the HTML select, passed as as get parameter
        // (string to match 'value' property of the SelectListItem class
        // Note: [BindProperty] tells the runtime to populate this property for us
        //
        [BindProperty(SupportsGet = true)]
        public string strNumSelected { get; set; }


        public CounterWithSelectAndTagHelpersModel()
        {

            // populate slNumbers with the items we want in our select dropdown
            //
            slNumbers = new List<SelectListItem>();
            slNumbers.Add(new SelectListItem("one", "1"));
            slNumbers.Add(new SelectListItem("two", "2"));
            slNumbers.Add(new SelectListItem("three", "3"));
            slNumbers.Add(new SelectListItem("four", "4"));

            // set defaults
            strNumSelected = "-1";
        }
    }
}
