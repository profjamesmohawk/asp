﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor01.Models;

namespace Razor01.Pages;



public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public List<string> NumberStrings { get; set; }
    public List<NumberAndName> NumbersAndNames { get; set; }

    public int numSelected;

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;

        NumbersAndNames = new List<NumberAndName>();
        NumbersAndNames.Add(new NumberAndName(1, "one"));
        NumbersAndNames.Add(new NumberAndName(2, "two"));
        NumbersAndNames.Add(new NumberAndName(3, "three"));
        NumbersAndNames.Add(new NumberAndName(4, "four"));

        numSelected = 0;
    }

 
    public void OnGet(int numSelect=-1)
    {
        ViewData["Msg"] = "in post";

        this.numSelected = numSelect;
    }
    
   me
 
}
