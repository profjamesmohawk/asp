using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Server.Kestrel.Core.Features;

namespace Razor01.Pages;

public class CounterWithGetParamModel : PageModel
{

    [BindProperty(SupportsGet = true)]
    public int? nCount { get; set; }

    public void OnGet()
    {
        
    }
}
