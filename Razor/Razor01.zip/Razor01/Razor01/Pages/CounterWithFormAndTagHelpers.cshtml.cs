using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razor01.Pages
{
    public class CouterWithFormAndTagHelpersModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public int nCount { get; set; } = 5;
        public void OnGet()
        {
        }
    }
}
