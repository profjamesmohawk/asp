﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razor01.Pages
{
    public class AuthorshipModel : PageModel
    {
        private readonly ILogger<AuthorshipModel> _logger;

        public AuthorshipModel(ILogger<AuthorshipModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
        }
    }

}
