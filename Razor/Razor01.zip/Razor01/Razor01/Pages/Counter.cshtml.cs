using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razor01.Pages;

public class CounterModel : PageModel
{
    public void OnGet()
    {
    }
}
